package Q_04;

public class Snippet {
	Join_EX member = new Join_EX (iName, iID, iPW, iPh, iEmail);
			member.printinfo();
}

