package Q_05;

class Marine extends Unit {
	public void stimPack() {
		
	}
}

class Dropship extends Unit{
	public void load( ) {
	}
	public void unload( ) {
	}
}

class Tank extends Unit {
	public void changeMode() {
		
	}
}



public class Unit {

	int x,y;
	
	public void move (int x, int y) {
		
	}
	
	public void stop() {
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
